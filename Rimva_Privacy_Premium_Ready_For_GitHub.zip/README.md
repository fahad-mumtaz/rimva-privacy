# Rimva Privacy Policy

Static privacy policy website for the Rimva Chrome extension.

Publish `index.html` at repository root using GitHub Pages: Settings > Pages > Deploy from a branch > main > /(root).

Expected URL: https://fahad-mumtaz.github.io/rimva-privacy/

Review factual data handling claims against the release build before publication. Add a public support email.
